Page({
  data: {
    getback: function () {
      wx.navigateBack({
        url: '../post/post'
      })
    }
  },
  data: {
    markers: [{
      iconPath: "../../images/locat.png",
      id: 0,
      latitude: 40.808214,
      longitude: 111.662453,
      width: 20,
      height: 20
    }]
  },
  regionchange(e) {
    console.log(e.type)
  },
  markertap(e) {
    console.log(e.markerId)
  },
  controltap(e) {
    console.log(e.controlId)
  },
  
})