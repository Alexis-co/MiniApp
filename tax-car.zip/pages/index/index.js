Page({
  data:{
    //这里是名片图
    imgItems:[
      {
        id:1,
        img:'../../images/yizuche.png'
      }
    ],
    // 这里是轮播土地址
    imgUrls: [   
      '../../images/buick.jpg',
      '../../images/range.jpg',
      '../../images/toyota.jpg'
    ],
    //这里是介绍文字
    listItema:[
          {
            id:1,
            neirong:'义租车致力于“服务至上、价格优惠、安全管理、保障有力”的经营方针，秉承着“方便客户、服务客户”的经营理念为客户提供提供专业化的汽车租赁服务。'
          },
          {
            id:2,
            neirong:'义租车专业致力于商务、会议、婚庆、旅游、接（送）机、个人自驾旅游出行、代驾出行等方面的汽车租赁服务。'
          },
          {
            id:3,
            neirong:'本公司自有及可控车型包括：宾利、奔驰、宝马、路虎、丰田、奥迪等高中档车型以及别克（GL8商务车、陆尊）、各类越野车、交通班车和旅游大巴等各类车型。'
          }
    ],
    //所需证件以及说明
    contentItems:[
          {
            id:1,
            img:'../../images/needa.png',
           // biaoti:'身份证'
          },
          {
            id:2,
            img:'../../images/needb.png',
           // biaoti:'驾驶证'
          },
          {
            id:3,
            img:'../../images/needc.png',
           // biaoti:'信用卡'
          },
          {
            id:4,
            img:'../../images/needd.png',
           // biaoti:'押金'
          },
    ]
  },
// 拨打电话
  callmeTap: function () {
    wx.makePhoneCall({
      phoneNumber: '12345678900', //此号码并非真实电话号码，仅用于测试
      success: function () {
        console.log("拨打电话成功！")
      },
      fail: function () {
        console.log("拨打电话失败！")
      }
    })
  } ,

  click:function () {
  wx.navigateTo({
    url: '../logs/logs',
    success: function(res){
      // success
    },
    fail: function() {
      // fail
    },
    complete: function() {
      // complete
    },
   
  })
  }
})