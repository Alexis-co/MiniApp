// pages/post/post.js
Page({
  data:{
  //地址电话
  adressItems: [
      
      {
        id: 1,
        img: '../../images/time.png',
        content :'8:30——18：00'
      },
      {
        id: 2,
        img: '../../images/phone.png',
        content: '0471-2527400'
      },
      {
        id: 3,
        img: '../../images/picture.png',
        content:'门店照片:'
      },
      
    ]
   },
  storea: function () {
    wx.navigateTo({
      url: '../userinfo/userinfo',
    })
  },
  storeb:function(){
    wx.navigateTo({
      url: '../logs/logs',
    })
  },
  
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  }
})